
package simplecalculator;


public class Simplecalculator {

 
    public static void main(String[] args) {
       
        calculator c = new calculator();
        c.show();
    }
    
}
